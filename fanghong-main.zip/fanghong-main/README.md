# QQ微信防红

当前版本:v1.6 [更新日志](https://github.com/foxplaying/fanghong/blob/main/Update.log.md)(已永远停止维护)

## 引言

利用`zeabur.app`做的防红链接，禁止生成非法网站，违反后果自行承担。

强烈推荐用Github和cloudflare的pages功能和以下托管平台域名自建防红 

Github防红html下载地址(open是直链，jump是跳转) 

https://github.com/ourls/ourls.github.io 

白名单自动通过域名: 

github.io，pages.dev，zeabur.app，netlify.app 

## 使用方法

进入该网址：[fanghong.zeabur.app](https://fanghong.zeabur.app)

用户反馈群: [598393246](https://qm.qq.com/q/ACKzmtExXy)
